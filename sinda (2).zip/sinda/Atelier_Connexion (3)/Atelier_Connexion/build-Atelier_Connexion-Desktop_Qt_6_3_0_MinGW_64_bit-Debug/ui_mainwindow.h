/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *viewbutton;
    QLabel *label_18;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QPushButton *pushButton_22;
    QPushButton *pushButton_25;
    QPushButton *modbutton;
    QPushButton *pushButton_20;
    QPushButton *pushButton_19;
    QLabel *label_17;
    QPushButton *pushButton_21;
    QPushButton *addbutton;
    QLabel *label_2;
    QStackedWidget *stackedWidget;
    QWidget *addemp;
    QLineEdit *cin;
    QPushButton *ajouterButton;
    QPushButton *pushButton_31;
    QPushButton *pushButton_32;
    QPushButton *pushButton_33;
    QDateTimeEdit *bdate;
    QDateTimeEdit *wdate;
    QPushButton *pushButton_51;
    QPushButton *pushButton_34;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QPushButton *pushButton_52;
    QPushButton *pushButton_53;
    QPushButton *pushButton_54;
    QLineEdit *fname;
    QLineEdit *name;
    QLineEdit *email;
    QLineEdit *number;
    QLineEdit *job;
    QLineEdit *sexe;
    QWidget *modemp;
    QPushButton *pushButton_40;
    QPushButton *pushButton_42;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_20;
    QPushButton *pushButton_41;
    QPushButton *pushButton_45;
    QPushButton *pushButton_55;
    QPushButton *pushButton_39;
    QDateTimeEdit *dateTimeEdit_3;
    QPushButton *pushButton_43;
    QPushButton *pushButton_57;
    QPushButton *pushButton_38;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_13;
    QPushButton *pushButton_44;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_14;
    QDateTimeEdit *dateTimeEdit_4;
    QPushButton *pushButton_58;
    QPushButton *pushButton_56;
    QWidget *statemp;
    QWidget *viewemp;
    QTableView *tableView;
    QLabel *label_3;
    QPushButton *pushButton_46;
    QPushButton *pushButton_47;
    QPushButton *pushButton_48;
    QPushButton *pushButton_49;
    QPushButton *pushButton_50;
    QPushButton *statbutton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1299, 804);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        viewbutton = new QPushButton(centralwidget);
        viewbutton->setObjectName(QString::fromUtf8("viewbutton"));
        viewbutton->setGeometry(QRect(250, 50, 171, 41));
        viewbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        label_18 = new QLabel(centralwidget);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(40, 560, 171, 111));
        label_18->setStyleSheet(QString::fromUtf8("background-color: rgb(214, 245, 124);\n"
"background-color: rgb(216, 242, 117);\n"
"border-radius:15px"));
        pushButton_23 = new QPushButton(centralwidget);
        pushButton_23->setObjectName(QString::fromUtf8("pushButton_23"));
        pushButton_23->setGeometry(QRect(40, 170, 171, 41));
        pushButton_23->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(255, 255, 255);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        pushButton_24 = new QPushButton(centralwidget);
        pushButton_24->setObjectName(QString::fromUtf8("pushButton_24"));
        pushButton_24->setGeometry(QRect(40, 270, 171, 41));
        pushButton_24->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(255, 255, 255);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        pushButton_22 = new QPushButton(centralwidget);
        pushButton_22->setObjectName(QString::fromUtf8("pushButton_22"));
        pushButton_22->setGeometry(QRect(40, 420, 171, 41));
        pushButton_22->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(255, 255, 255);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        pushButton_25 = new QPushButton(centralwidget);
        pushButton_25->setObjectName(QString::fromUtf8("pushButton_25"));
        pushButton_25->setGeometry(QRect(40, 320, 171, 41));
        pushButton_25->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(255, 255, 255);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        modbutton = new QPushButton(centralwidget);
        modbutton->setObjectName(QString::fromUtf8("modbutton"));
        modbutton->setGeometry(QRect(720, 50, 171, 41));
        modbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_20 = new QPushButton(centralwidget);
        pushButton_20->setObjectName(QString::fromUtf8("pushButton_20"));
        pushButton_20->setGeometry(QRect(40, 120, 171, 41));
        pushButton_20->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	color: rgb(255, 255, 255);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 18px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"\n"
"\n"
"}"));
        pushButton_19 = new QPushButton(centralwidget);
        pushButton_19->setObjectName(QString::fromUtf8("pushButton_19"));
        pushButton_19->setGeometry(QRect(50, 370, 171, 41));
        pushButton_19->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        label_17 = new QLabel(centralwidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(100, 540, 51, 51));
        label_17->setStyleSheet(QString::fromUtf8("background-color: white;\n"
"border-radius:24px;\n"
"border-color:rgb(33,37,41);\n"
"border:6px solid;\n"
"width:30px;\n"
"height:30px;"));
        pushButton_21 = new QPushButton(centralwidget);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setGeometry(QRect(40, 220, 171, 41));
        pushButton_21->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(255, 255, 255);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        addbutton = new QPushButton(centralwidget);
        addbutton->setObjectName(QString::fromUtf8("addbutton"));
        addbutton->setGeometry(QRect(490, 50, 171, 41));
        addbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 10, 211, 691));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(33, 33, 41);\n"
"border-radius:20px;\n"
""));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(240, 110, 961, 601));
        addemp = new QWidget();
        addemp->setObjectName(QString::fromUtf8("addemp"));
        cin = new QLineEdit(addemp);
        cin->setObjectName(QString::fromUtf8("cin"));
        cin->setGeometry(QRect(300, 70, 471, 31));
        cin->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        ajouterButton = new QPushButton(addemp);
        ajouterButton->setObjectName(QString::fromUtf8("ajouterButton"));
        ajouterButton->setGeometry(QRect(530, 550, 221, 41));
        ajouterButton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_31 = new QPushButton(addemp);
        pushButton_31->setObjectName(QString::fromUtf8("pushButton_31"));
        pushButton_31->setGeometry(QRect(300, 540, 201, 41));
        pushButton_31->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_32 = new QPushButton(addemp);
        pushButton_32->setObjectName(QString::fromUtf8("pushButton_32"));
        pushButton_32->setGeometry(QRect(0, 70, 281, 41));
        pushButton_32->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_33 = new QPushButton(addemp);
        pushButton_33->setObjectName(QString::fromUtf8("pushButton_33"));
        pushButton_33->setGeometry(QRect(0, 120, 281, 41));
        pushButton_33->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        bdate = new QDateTimeEdit(addemp);
        bdate->setObjectName(QString::fromUtf8("bdate"));
        bdate->setGeometry(QRect(300, 290, 471, 31));
        bdate->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 1px solid transparent;  /* Makes the border transparent */\n"
"    background-color: white;  /* Optional: sets the background color */"));
        wdate = new QDateTimeEdit(addemp);
        wdate->setObjectName(QString::fromUtf8("wdate"));
        wdate->setGeometry(QRect(300, 340, 471, 31));
        wdate->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 1px solid transparent;  /* Makes the border transparent */\n"
"  background-color: white;  /* Optional: sets the background color */"));
        pushButton_51 = new QPushButton(addemp);
        pushButton_51->setObjectName(QString::fromUtf8("pushButton_51"));
        pushButton_51->setGeometry(QRect(290, 10, 301, 41));
        pushButton_51->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 30px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        pushButton_34 = new QPushButton(addemp);
        pushButton_34->setObjectName(QString::fromUtf8("pushButton_34"));
        pushButton_34->setGeometry(QRect(0, 170, 281, 41));
        pushButton_34->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_35 = new QPushButton(addemp);
        pushButton_35->setObjectName(QString::fromUtf8("pushButton_35"));
        pushButton_35->setGeometry(QRect(0, 220, 281, 41));
        pushButton_35->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_36 = new QPushButton(addemp);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setGeometry(QRect(0, 280, 281, 41));
        pushButton_36->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_37 = new QPushButton(addemp);
        pushButton_37->setObjectName(QString::fromUtf8("pushButton_37"));
        pushButton_37->setGeometry(QRect(0, 330, 281, 41));
        pushButton_37->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_52 = new QPushButton(addemp);
        pushButton_52->setObjectName(QString::fromUtf8("pushButton_52"));
        pushButton_52->setGeometry(QRect(-10, 380, 281, 41));
        pushButton_52->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_53 = new QPushButton(addemp);
        pushButton_53->setObjectName(QString::fromUtf8("pushButton_53"));
        pushButton_53->setGeometry(QRect(0, 430, 281, 41));
        pushButton_53->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_54 = new QPushButton(addemp);
        pushButton_54->setObjectName(QString::fromUtf8("pushButton_54"));
        pushButton_54->setGeometry(QRect(0, 490, 281, 41));
        pushButton_54->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        fname = new QLineEdit(addemp);
        fname->setObjectName(QString::fromUtf8("fname"));
        fname->setGeometry(QRect(300, 120, 471, 31));
        fname->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        name = new QLineEdit(addemp);
        name->setObjectName(QString::fromUtf8("name"));
        name->setGeometry(QRect(300, 180, 471, 31));
        name->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        email = new QLineEdit(addemp);
        email->setObjectName(QString::fromUtf8("email"));
        email->setGeometry(QRect(300, 230, 471, 31));
        email->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        number = new QLineEdit(addemp);
        number->setObjectName(QString::fromUtf8("number"));
        number->setGeometry(QRect(300, 390, 471, 31));
        number->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        job = new QLineEdit(addemp);
        job->setObjectName(QString::fromUtf8("job"));
        job->setGeometry(QRect(300, 440, 471, 31));
        job->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        sexe = new QLineEdit(addemp);
        sexe->setObjectName(QString::fromUtf8("sexe"));
        sexe->setGeometry(QRect(300, 490, 471, 31));
        sexe->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        stackedWidget->addWidget(addemp);
        modemp = new QWidget();
        modemp->setObjectName(QString::fromUtf8("modemp"));
        pushButton_40 = new QPushButton(modemp);
        pushButton_40->setObjectName(QString::fromUtf8("pushButton_40"));
        pushButton_40->setGeometry(QRect(270, 550, 201, 41));
        pushButton_40->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_42 = new QPushButton(modemp);
        pushButton_42->setObjectName(QString::fromUtf8("pushButton_42"));
        pushButton_42->setGeometry(QRect(540, 550, 221, 41));
        pushButton_42->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        lineEdit_21 = new QLineEdit(modemp);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(360, 390, 471, 31));
        lineEdit_21->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        lineEdit_20 = new QLineEdit(modemp);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(360, 440, 471, 31));
        lineEdit_20->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        pushButton_41 = new QPushButton(modemp);
        pushButton_41->setObjectName(QString::fromUtf8("pushButton_41"));
        pushButton_41->setGeometry(QRect(60, 120, 281, 41));
        pushButton_41->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_45 = new QPushButton(modemp);
        pushButton_45->setObjectName(QString::fromUtf8("pushButton_45"));
        pushButton_45->setGeometry(QRect(60, 170, 281, 41));
        pushButton_45->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_55 = new QPushButton(modemp);
        pushButton_55->setObjectName(QString::fromUtf8("pushButton_55"));
        pushButton_55->setGeometry(QRect(60, 430, 281, 41));
        pushButton_55->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_39 = new QPushButton(modemp);
        pushButton_39->setObjectName(QString::fromUtf8("pushButton_39"));
        pushButton_39->setGeometry(QRect(60, 70, 281, 41));
        pushButton_39->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        dateTimeEdit_3 = new QDateTimeEdit(modemp);
        dateTimeEdit_3->setObjectName(QString::fromUtf8("dateTimeEdit_3"));
        dateTimeEdit_3->setGeometry(QRect(360, 290, 471, 31));
        dateTimeEdit_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 1px solid transparent;  /* Makes the border transparent */\n"
"    background-color: white;  /* Optional: sets the background color */"));
        pushButton_43 = new QPushButton(modemp);
        pushButton_43->setObjectName(QString::fromUtf8("pushButton_43"));
        pushButton_43->setGeometry(QRect(60, 330, 281, 41));
        pushButton_43->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_57 = new QPushButton(modemp);
        pushButton_57->setObjectName(QString::fromUtf8("pushButton_57"));
        pushButton_57->setGeometry(QRect(50, 380, 281, 41));
        pushButton_57->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_38 = new QPushButton(modemp);
        pushButton_38->setObjectName(QString::fromUtf8("pushButton_38"));
        pushButton_38->setGeometry(QRect(60, 220, 281, 41));
        pushButton_38->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        lineEdit_15 = new QLineEdit(modemp);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(360, 70, 471, 31));
        lineEdit_15->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        lineEdit_11 = new QLineEdit(modemp);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(360, 120, 471, 31));
        lineEdit_11->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        lineEdit_13 = new QLineEdit(modemp);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(360, 230, 471, 31));
        lineEdit_13->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        pushButton_44 = new QPushButton(modemp);
        pushButton_44->setObjectName(QString::fromUtf8("pushButton_44"));
        pushButton_44->setGeometry(QRect(60, 280, 281, 41));
        pushButton_44->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        lineEdit_19 = new QLineEdit(modemp);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(360, 490, 471, 31));
        lineEdit_19->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        lineEdit_14 = new QLineEdit(modemp);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(360, 180, 471, 31));
        lineEdit_14->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    color: blue;  /* Change la couleur du texte en bleu */\n"
"    font-family: 'Sans-Serif';\n"
"    font-size: 20px;\n"
"    background-color: white;  /* Couleur de fond blanche */\n"
"    border-radius: 20px;\n"
"}\n"
""));
        dateTimeEdit_4 = new QDateTimeEdit(modemp);
        dateTimeEdit_4->setObjectName(QString::fromUtf8("dateTimeEdit_4"));
        dateTimeEdit_4->setGeometry(QRect(360, 340, 471, 31));
        dateTimeEdit_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border: 1px solid transparent;  /* Makes the border transparent */\n"
"  background-color: white;  /* Optional: sets the background color */"));
        pushButton_58 = new QPushButton(modemp);
        pushButton_58->setObjectName(QString::fromUtf8("pushButton_58"));
        pushButton_58->setGeometry(QRect(330, 10, 431, 41));
        pushButton_58->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 30px;    \n"
"	background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"}"));
        pushButton_56 = new QPushButton(modemp);
        pushButton_56->setObjectName(QString::fromUtf8("pushButton_56"));
        pushButton_56->setGeometry(QRect(60, 490, 281, 41));
        pushButton_56->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 24px;    \n"
" background-color: transparent;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        stackedWidget->addWidget(modemp);
        statemp = new QWidget();
        statemp->setObjectName(QString::fromUtf8("statemp"));
        stackedWidget->addWidget(statemp);
        viewemp = new QWidget();
        viewemp->setObjectName(QString::fromUtf8("viewemp"));
        tableView = new QTableView(viewemp);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(30, 100, 641, 451));
        label_3 = new QLabel(viewemp);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(720, 160, 221, 301));
        label_3->setStyleSheet(QString::fromUtf8("background-color: rgb(33, 33, 41);\n"
"border-radius:20px;\n"
""));
        pushButton_46 = new QPushButton(viewemp);
        pushButton_46->setObjectName(QString::fromUtf8("pushButton_46"));
        pushButton_46->setGeometry(QRect(740, 140, 171, 41));
        pushButton_46->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_47 = new QPushButton(viewemp);
        pushButton_47->setObjectName(QString::fromUtf8("pushButton_47"));
        pushButton_47->setGeometry(QRect(730, 210, 201, 41));
        pushButton_47->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_48 = new QPushButton(viewemp);
        pushButton_48->setObjectName(QString::fromUtf8("pushButton_48"));
        pushButton_48->setGeometry(QRect(730, 270, 201, 41));
        pushButton_48->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_49 = new QPushButton(viewemp);
        pushButton_49->setObjectName(QString::fromUtf8("pushButton_49"));
        pushButton_49->setGeometry(QRect(730, 330, 201, 41));
        pushButton_49->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        pushButton_50 = new QPushButton(viewemp);
        pushButton_50->setObjectName(QString::fromUtf8("pushButton_50"));
        pushButton_50->setGeometry(QRect(730, 390, 201, 41));
        pushButton_50->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        stackedWidget->addWidget(viewemp);
        statbutton = new QPushButton(centralwidget);
        statbutton->setObjectName(QString::fromUtf8("statbutton"));
        statbutton->setGeometry(QRect(980, 50, 171, 41));
        statbutton->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"color:rgb(33, 33, 41);\n"
"font-family: 'Sans-Serif';\n"
" font-size: 20px;    \n"
" background-color: rgb(209, 255, 117);;\n"
"border-radius:20px;\n"
"font-color:white;\n"
"\n"
"\n"
"}"));
        MainWindow->setCentralWidget(centralwidget);
        label_2->raise();
        viewbutton->raise();
        label_18->raise();
        pushButton_23->raise();
        pushButton_24->raise();
        pushButton_22->raise();
        pushButton_25->raise();
        modbutton->raise();
        pushButton_20->raise();
        pushButton_19->raise();
        label_17->raise();
        pushButton_21->raise();
        addbutton->raise();
        stackedWidget->raise();
        statbutton->raise();

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
#if QT_CONFIG(tooltip)
        viewbutton->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        viewbutton->setText(QCoreApplication::translate("MainWindow", "View", nullptr));
        label_18->setText(QString());
        pushButton_23->setText(QCoreApplication::translate("MainWindow", "Employees", nullptr));
        pushButton_24->setText(QCoreApplication::translate("MainWindow", "Partners", nullptr));
        pushButton_22->setText(QCoreApplication::translate("MainWindow", "Partners", nullptr));
        pushButton_25->setText(QCoreApplication::translate("MainWindow", "Vehicles", nullptr));
#if QT_CONFIG(tooltip)
        modbutton->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        modbutton->setText(QCoreApplication::translate("MainWindow", "Modify/Delete", nullptr));
        pushButton_20->setText(QCoreApplication::translate("MainWindow", "Dashboard", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_19->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_19->setText(QCoreApplication::translate("MainWindow", "Services", nullptr));
        label_17->setText(QString());
        pushButton_21->setText(QCoreApplication::translate("MainWindow", "Clients", nullptr));
#if QT_CONFIG(tooltip)
        addbutton->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        addbutton->setText(QCoreApplication::translate("MainWindow", "ADD", nullptr));
        label_2->setText(QString());
#if QT_CONFIG(tooltip)
        ajouterButton->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        ajouterButton->setText(QCoreApplication::translate("MainWindow", "Register  ", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_31->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_31->setText(QCoreApplication::translate("MainWindow", "Crush", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_32->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_32->setText(QCoreApplication::translate("MainWindow", "CIN:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_33->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_33->setText(QCoreApplication::translate("MainWindow", "FamilyName", nullptr));
        pushButton_51->setText(QCoreApplication::translate("MainWindow", "ADD EMPLOYEE", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_34->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_34->setText(QCoreApplication::translate("MainWindow", "NAME:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_35->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_35->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_36->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_36->setText(QCoreApplication::translate("MainWindow", "Birth date :", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_37->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_37->setText(QCoreApplication::translate("MainWindow", "Work day :", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_52->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_52->setText(QCoreApplication::translate("MainWindow", "Phone Number:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_53->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_53->setText(QCoreApplication::translate("MainWindow", "JOB:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_54->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_54->setText(QCoreApplication::translate("MainWindow", "SEX:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_40->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_40->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_42->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_42->setText(QCoreApplication::translate("MainWindow", "Modify", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_41->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_41->setText(QCoreApplication::translate("MainWindow", "FamilyName", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_45->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_45->setText(QCoreApplication::translate("MainWindow", "NAME:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_55->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_55->setText(QCoreApplication::translate("MainWindow", "JOB:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_39->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_39->setText(QCoreApplication::translate("MainWindow", "CIN:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_43->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_43->setText(QCoreApplication::translate("MainWindow", "Work day :", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_57->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_57->setText(QCoreApplication::translate("MainWindow", "Phone Number:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_38->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_38->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_44->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_44->setText(QCoreApplication::translate("MainWindow", "Birth date :", nullptr));
        pushButton_58->setText(QCoreApplication::translate("MainWindow", "Modify /Delete Employee", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_56->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_56->setText(QCoreApplication::translate("MainWindow", "SEX:", nullptr));
        label_3->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_46->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_46->setText(QCoreApplication::translate("MainWindow", "Tools", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_47->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_47->setText(QCoreApplication::translate("MainWindow", "PDF", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_48->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_48->setText(QCoreApplication::translate("MainWindow", "EXCEL", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_49->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_49->setText(QCoreApplication::translate("MainWindow", "Image Recognition", nullptr));
#if QT_CONFIG(tooltip)
        pushButton_50->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_50->setText(QCoreApplication::translate("MainWindow", "To-Do List", nullptr));
#if QT_CONFIG(tooltip)
        statbutton->setToolTip(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d1d938;\">employees</span></p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        statbutton->setText(QCoreApplication::translate("MainWindow", "Stats", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
